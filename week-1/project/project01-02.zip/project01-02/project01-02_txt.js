/*  JavaScript 7th Edition
    Chapter 1
    Hands-On Project 1-2

    Author: 
    Date:   

    Filename: project01-02.js
*/

//define variables for service name and service speed
